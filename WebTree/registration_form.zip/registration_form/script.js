function validateForm() {
  const name = document.getElementById("fullname").value;
  const email = document.getElementById("email").value;
  const phone = document.getElementById("phone").value;
  const address = document.getElementById("address").value;

  const namePattern = /^[A-Z][a-z]+\s[A-Z]?[a-z]*$/;
  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  if (!namePattern.test(name)) {
    alert("Full name must start with a capital letter.");
    return false;
  }

  if (!emailPattern.test(email)) {
    alert("Invalid email format.");
    return false;
  }

  if (phone.length !== 10 || isNaN(phone)) {
    alert("Phone number must be exactly 10 digits.");
    return false;
  }

  if (address.length < 10) {
    alert("Address must be at least 10 characters long.");
    return false;
  }

  return true;
}
