<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "registration_form";

// Connect
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// === SANITIZATION === //
function sanitize_input($data) {
  $data = trim($data);                  // Remove whitespace
  $data = stripslashes($data);          // Remove backslashes
  $data = htmlspecialchars($data);      // Convert special characters to HTML entities
  return $data;
}

$fullname = sanitize_input($_POST["fullname"]);
$email = sanitize_input($_POST["email"]);
$phone = sanitize_input($_POST["phone"]);
$address = sanitize_input($_POST["address"]);

// === VALIDATION === //

// Check name (only letters and spaces)
if (!preg_match("/^([A-Z][a-z]*)( [A-Z][a-z]*)*$/", $fullname)) {
  header("Location: index.php?success=0&error=invalid_name");
  exit();
}

// Check valid email
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
  header("Location: index.php?success=0&error=invalid_email");
  exit();
}

// Check valid 10-digit phone number
if (!preg_match("/^[0-9]{10}$/", $phone)) {
  header("Location: index.php?success=0&error=invalid_phone");
  exit();
}

// Check address length
if (strlen($address) < 10) {
  header("Location: index.php?success=0&error=invalid_address");
  exit();
}

// === UNIQUE CHECK === //
$checkSql = "SELECT * FROM users WHERE email = ? OR phone = ?";
$checkStmt = $conn->prepare($checkSql);
$checkStmt->bind_param("ss", $email, $phone);
$checkStmt->execute();
$result = $checkStmt->get_result();

if ($result->num_rows > 0) {
  header("Location: index.php?success=0&error=duplicate");
  exit();
}

// === INSERT INTO DATABASE === //
$sql = "INSERT INTO users (fullname, email, phone, address) VALUES (?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ssss", $fullname, $email, $phone, $address);

if ($stmt->execute()) {
  header("Location: index.php?success=1");
  exit();
} else {
  echo "Error: " . $stmt->error;
}

$conn->close();
?>
