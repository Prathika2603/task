<?php
if (isset($_GET['success']) && $_GET['success'] == '1') {
  echo "<div class='success'>✅ Registration successful!</div>";
} elseif (isset($_GET['error'])) {
  $error = $_GET['error'];
  $messages = [
    "duplicate" => "❌ Email or Phone already registered!",
    "invalid_name" => "❌ Name should contain only letters and spaces.",
    "invalid_email" => "❌ Please enter a valid email address.",
    "invalid_phone" => "❌ Phone number must be exactly 10 digits.",
    "invalid_address" => "❌ Address must be at least 10 characters long."
  ];
  if (array_key_exists($error, $messages)) {
    echo "<div class='error'>{$messages[$error]}</div>";
  }
}
?>
